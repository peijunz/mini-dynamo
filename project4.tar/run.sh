#/bin/bash

make clean
make

./test_app
